package com.fabrica.pizza;

import com.fabrica.pizza.fabrica.PizzaIngredienteFabrica;
import com.fabrica.pizza.fabrica.PizzariaSaoPauloFabrica;
import com.fabrica.pizza.fabrica.PizzariaAmericanaFabrica;
import com.fabrica.pizza.pizzas.Pizza;
import com.fabrica.pizza.pizzas.PizzaCalabresa;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE PIZZARIA - PADRÃO ABSTRACT FACTORY ===");
        
        // Pedido na Franquia de São Paulo
        System.out.println("\n--- Pedido na Unidade São Paulo ---");
        PizzaIngredienteFabrica fabricaSP = new PizzariaSaoPauloFabrica();
        Pizza pizzaSP = new PizzaCalabresa(fabricaSP);
        pizzaSP.setNome("Pizza Calabresa Moda SP");
        pizzaSP.preparar();
        pizzaSP.assar();
        pizzaSP.cortar();
        pizzaSP.empacotar();
        System.out.println(pizzaSP);

        // Pedido na Franquia Americana
        System.out.println("\n--- Pedido na Unidade Americana ---");
        PizzaIngredienteFabrica fabricaUS = new PizzariaAmericanaFabrica();
        Pizza pizzaUS = new PizzaCalabresa(fabricaUS);
        pizzaUS.setNome("Pizza Calabresa Moda EUA");
        pizzaUS.preparar();
        pizzaUS.assar();
        pizzaUS.cortar();
        pizzaUS.empacotar();
        System.out.println(pizzaUS);
    }
}
