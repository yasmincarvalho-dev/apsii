package com.fabrica.pizza.ingredientes;

public interface Queijo {
    String exibirIngrediente();
}
