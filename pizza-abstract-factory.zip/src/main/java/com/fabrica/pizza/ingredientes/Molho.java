package com.fabrica.pizza.ingredientes;

public interface Molho {
    String exibirIngrediente();
}
