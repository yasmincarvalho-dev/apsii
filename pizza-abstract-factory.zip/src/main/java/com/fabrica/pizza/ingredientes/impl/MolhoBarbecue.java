package com.fabrica.pizza.ingredientes.impl;

import com.fabrica.pizza.ingredientes.Molho;

public class MolhoBarbecue implements Molho {
    @Override
    public String exibirIngrediente() {
        return "Molho barbecue defumado especial";
    }
}
