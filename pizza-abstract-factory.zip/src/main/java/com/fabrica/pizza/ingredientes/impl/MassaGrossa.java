package com.fabrica.pizza.ingredientes.impl;

import com.fabrica.pizza.ingredientes.Massa;

public class MassaGrossa implements Massa {
    @Override
    public String exibirIngrediente() {
        return "Massa grossa estilo pan (fofinha)";
    }
}
