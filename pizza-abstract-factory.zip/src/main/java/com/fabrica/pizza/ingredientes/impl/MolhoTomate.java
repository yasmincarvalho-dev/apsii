package com.fabrica.pizza.ingredientes.impl;

import com.fabrica.pizza.ingredientes.Molho;

public class MolhoTomate implements Molho {
    @Override
    public String exibirIngrediente() {
        return "Molho de tomate tradicional italiano";
    }
}
