package com.fabrica.pizza.ingredientes.impl;

import com.fabrica.pizza.ingredientes.Queijo;

public class QueijoCheddar implements Queijo {
    @Override
    public String exibirIngrediente() {
        return "Queijo cheddar cremoso e marcante";
    }
}
