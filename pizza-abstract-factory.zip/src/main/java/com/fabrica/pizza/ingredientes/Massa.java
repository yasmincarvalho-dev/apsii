package com.fabrica.pizza.ingredientes;

public interface Massa {
    String exibirIngrediente();
}
