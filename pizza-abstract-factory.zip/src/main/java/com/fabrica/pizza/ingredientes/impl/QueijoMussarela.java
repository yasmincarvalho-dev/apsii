package com.fabrica.pizza.ingredientes.impl;

import com.fabrica.pizza.ingredientes.Queijo;

public class QueijoMussarela implements Queijo {
    @Override
    public String exibirIngrediente() {
        return "Queijo mussarela ralado fresquinho";
    }
}
