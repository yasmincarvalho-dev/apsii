package com.fabrica.pizza.ingredientes.impl;

import com.fabrica.pizza.ingredientes.Massa;

public class MassaFina implements Massa {
    @Override
    public String exibirIngrediente() {
        return "Massa fininha e crocante";
    }
}
