package com.fabrica.pizza.fabrica;

import com.fabrica.pizza.ingredientes.Massa;
import com.fabrica.pizza.ingredientes.Molho;
import com.fabrica.pizza.ingredientes.Queijo;
import com.fabrica.pizza.ingredientes.impl.MassaFina;
import com.fabrica.pizza.ingredientes.impl.MolhoTomate;
import com.fabrica.pizza.ingredientes.impl.QueijoMussarela;

public class PizzariaSaoPauloFabrica implements PizzaIngredienteFabrica {
    @Override
    public Massa criarMassa() {
        return new MassaFina();
    }

    @Override
    public Molho criarMolho() {
        return new MolhoTomate();
    }

    @Override
    public Queijo criarQueijo() {
        return new QueijoMussarela();
    }
}
