package com.fabrica.pizza.fabrica;

import com.fabrica.pizza.ingredientes.Massa;
import com.fabrica.pizza.ingredientes.Molho;
import com.fabrica.pizza.ingredientes.Queijo;

public interface PizzaIngredienteFabrica {
    Massa criarMassa();
    Molho criarMolho();
    Queijo criarQueijo();
}
