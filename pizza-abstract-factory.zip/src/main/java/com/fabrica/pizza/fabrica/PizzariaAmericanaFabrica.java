package com.fabrica.pizza.fabrica;

import com.fabrica.pizza.ingredientes.Massa;
import com.fabrica.pizza.ingredientes.Molho;
import com.fabrica.pizza.ingredientes.Queijo;
import com.fabrica.pizza.ingredientes.impl.MassaGrossa;
import com.fabrica.pizza.ingredientes.impl.MolhoBarbecue;
import com.fabrica.pizza.ingredientes.impl.QueijoCheddar;

public class PizzariaAmericanaFabrica implements PizzaIngredienteFabrica {
    @Override
    public Massa criarMassa() {
        return new MassaGrossa();
    }

    @Override
    public Molho criarMolho() {
        return new MolhoBarbecue();
    }

    @Override
    public Queijo criarQueijo() {
        return new QueijoCheddar();
    }
}
