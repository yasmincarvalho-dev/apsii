package com.fabrica.pizza.pizzas;

import com.fabrica.pizza.fabrica.PizzaIngredienteFabrica;

public class PizzaCalabresa extends Pizza {
    PizzaIngredienteFabrica fabrica;

    public PizzaCalabresa(PizzaIngredienteFabrica fabrica) {
        this.fabrica = fabrica;
    }

    @Override
    public void preparar() {
        System.out.println("Preparando " + nome);
        massa = fabrica.criarMassa();
        molho = fabrica.criarMolho();
        queijo = fabrica.criarQueijo();
    }
}
