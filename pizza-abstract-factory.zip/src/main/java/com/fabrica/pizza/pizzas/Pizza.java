package com.fabrica.pizza.pizzas;

import com.fabrica.pizza.ingredientes.Massa;
import com.fabrica.pizza.ingredientes.Molho;
import com.fabrica.pizza.ingredientes.Queijo;

public abstract class Pizza {
    protected String nome;
    protected Massa massa;
    protected Molho molho;
    protected Queijo queijo;

    public abstract void preparar();

    public void assar() {
        System.out.println("Assando por 25 minutos a 350 graus...");
    }

    public void cortar() {
        System.out.println("Cortando a pizza em fatias triangulares.");
    }

    public void empacotar() {
        System.out.println("Colocando a pizza na caixa oficial da pizzaria.");
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("--- Pizza: ").append(nome).append(" ---\n");
        if (massa != null) sb.append("Massa: ").append(massa.exibirIngrediente()).append("\n");
        if (molho != null) sb.append("Molho: ").append(molho.exibirIngrediente()).append("\n");
        if (queijo != null) sb.append("Queijo: ").append(queijo.exibirIngrediente()).append("\n");
        return sb.toString();
    }
}
